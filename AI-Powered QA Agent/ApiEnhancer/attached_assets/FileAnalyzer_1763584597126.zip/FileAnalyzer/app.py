import streamlit as st
import os
import json
from pathlib import Path
from knowledge_base import KnowledgeBase
from test_case_agent import TestCaseAgent, SeleniumScriptAgent


st.set_page_config(
    page_title="Autonomous QA Agent",
    page_icon="🤖",
    layout="wide"
)


if 'kb' not in st.session_state:
    st.session_state.kb = None
if 'test_cases' not in st.session_state:
    st.session_state.test_cases = []
if 'generated_script' not in st.session_state:
    st.session_state.generated_script = None
if 'kb_stats' not in st.session_state:
    st.session_state.kb_stats = None


st.title("🤖 Autonomous QA Agent")
st.markdown("### Test Case and Selenium Script Generation System")
st.markdown("---")


api_key = os.environ.get("OPENAI_API_KEY")
if not api_key:
    st.error("⚠️ OPENAI_API_KEY environment variable is not set. Please configure it to use this application.")
    st.info("You can set the API key in the Secrets section of your Replit project.")
    st.stop()


st.sidebar.title("📋 Navigation")
phase = st.sidebar.radio(
    "Select Phase:",
    ["Phase 1: Knowledge Base", "Phase 2: Test Case Generation", "Phase 3: Selenium Script Generation"],
    index=0
)

st.sidebar.markdown("---")
st.sidebar.markdown("### About")
st.sidebar.info(
    "This system uses AI to:\n"
    "1. Build a knowledge base from your docs\n"
    "2. Generate grounded test cases\n"
    "3. Create Selenium scripts\n\n"
    "All test cases are based strictly on the provided documentation."
)

if st.session_state.kb_stats:
    st.sidebar.markdown("---")
    st.sidebar.markdown("### Knowledge Base Stats")
    st.sidebar.metric("Documents", st.session_state.kb_stats['total_documents'])
    st.sidebar.metric("Text Chunks", st.session_state.kb_stats['total_chunks'])
    st.sidebar.metric("HTML Loaded", "✓" if st.session_state.kb_stats['has_html'] else "✗")


if phase == "Phase 1: Knowledge Base":
    st.header("📚 Phase 1: Knowledge Base Ingestion")
    
    st.markdown("""
    Upload your project documentation and HTML file to build the knowledge base.
    Supported formats: **Markdown (.md)**, **Text (.txt)**, **JSON (.json)**, **PDF (.pdf)**, **HTML (.html)**
    """)
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("📄 Upload Support Documents")
        uploaded_docs = st.file_uploader(
            "Upload documentation files (MD, TXT, JSON, PDF)",
            type=['md', 'txt', 'json', 'pdf'],
            accept_multiple_files=True,
            help="Upload 3-5 support documents (product specs, UI/UX guides, API docs, etc.)"
        )
        
        st.subheader("🌐 Upload HTML File")
        uploaded_html = st.file_uploader(
            "Upload target HTML file",
            type=['html', 'htm'],
            help="Upload the checkout.html or paste HTML content below"
        )
        
        html_text = st.text_area(
            "Or paste HTML content here:",
            height=150,
            placeholder="<html>...</html>"
        )
    
    with col2:
        st.subheader("📦 Sample Files")
        st.info(
            "This project includes sample files:\n\n"
            "- checkout.html\n"
            "- product_specs.md\n"
            "- ui_ux_guide.txt\n"
            "- api_endpoints.json\n\n"
            "Located in `sample_project/` folder"
        )
        
        if st.button("📥 Load Sample Files", use_container_width=True):
            try:
                sample_files = []
                
                sample_dir = Path("sample_project")
                if sample_dir.exists():
                    for file_path in sample_dir.glob("*"):
                        if file_path.is_file():
                            with open(file_path, 'rb') as f:
                                content = f.read()
                                sample_files.append((content, file_path.name))
                    
                    if sample_files:
                        kb = KnowledgeBase()
                        with st.spinner("Building knowledge base from sample files..."):
                            results = kb.ingest_multiple_documents(sample_files)
                        
                        st.session_state.kb = kb
                        st.session_state.kb_stats = kb.get_stats()
                        
                        st.success(f"✅ Knowledge base built with {len(results)} sample files!")
                        
                        for result in results:
                            st.write(f"- {result['filename']}: {result['chunks_created']} chunks ({result['type']})")
                    else:
                        st.warning("No sample files found in sample_project/ directory")
                else:
                    st.warning("sample_project/ directory not found")
                    
            except Exception as e:
                st.error(f"Error loading sample files: {str(e)}")
    
    st.markdown("---")
    
    if st.button("🔨 Build Knowledge Base", type="primary", use_container_width=True):
        files_to_process = []
        
        if uploaded_docs:
            for uploaded_file in uploaded_docs:
                content = uploaded_file.read()
                files_to_process.append((content, uploaded_file.name))
        
        if uploaded_html:
            content = uploaded_html.read()
            files_to_process.append((content, uploaded_html.name))
        elif html_text.strip():
            files_to_process.append((html_text.encode('utf-8'), "pasted_html.html"))
        
        if not files_to_process:
            st.warning("⚠️ Please upload at least one document to build the knowledge base.")
        else:
            try:
                kb = KnowledgeBase()
                
                with st.spinner("🔄 Processing documents and building knowledge base..."):
                    results = kb.ingest_multiple_documents(files_to_process)
                
                st.session_state.kb = kb
                st.session_state.kb_stats = kb.get_stats()
                
                st.success("✅ Knowledge Base Built Successfully!")
                
                st.subheader("Ingestion Results:")
                for result in results:
                    st.write(f"✓ **{result['filename']}**: {result['chunks_created']} chunks created (Type: {result['type']})")
                
                stats = kb.get_stats()
                st.info(
                    f"📊 **Total Documents:** {stats['total_documents']} | "
                    f"**Total Chunks:** {stats['total_chunks']} | "
                    f"**HTML Loaded:** {'Yes' if stats['has_html'] else 'No'}"
                )
                
                st.balloons()
                
            except Exception as e:
                st.error(f"❌ Error building knowledge base: {str(e)}")


elif phase == "Phase 2: Test Case Generation":
    st.header("🧪 Phase 2: Test Case Generation")
    
    if st.session_state.kb is None:
        st.warning("⚠️ Please build the knowledge base first in Phase 1.")
        st.info("Go to Phase 1 and upload documents to create the knowledge base.")
    else:
        st.markdown("""
        Ask the AI agent to generate test cases based on the documentation in your knowledge base.
        The agent will retrieve relevant context and generate comprehensive, grounded test cases.
        """)
        
        example_queries = [
            "Generate all positive and negative test cases for the discount code feature",
            "Create test cases for form validation on the checkout page",
            "Generate test cases for the shopping cart functionality",
            "Create test cases for shipping method selection",
            "Generate test cases for the complete checkout flow"
        ]
        
        st.subheader("Example Queries:")
        cols = st.columns(3)
        for i, query in enumerate(example_queries):
            with cols[i % 3]:
                if st.button(f"📝 {query[:30]}...", key=f"example_{i}", use_container_width=True):
                    st.session_state.user_query = query
        
        user_query = st.text_area(
            "Enter your test case generation request:",
            value=st.session_state.get('user_query', ''),
            height=100,
            placeholder="Example: Generate all positive and negative test cases for the discount code feature"
        )
        
        col1, col2 = st.columns([3, 1])
        with col1:
            generate_btn = st.button("🚀 Generate Test Cases", type="primary", use_container_width=True)
        with col2:
            n_chunks = st.number_input("Context chunks", min_value=3, max_value=15, value=8, help="Number of document chunks to retrieve for context")
        
        if generate_btn:
            if not user_query.strip():
                st.warning("Please enter a test case generation request.")
            else:
                try:
                    agent = TestCaseAgent(st.session_state.kb)
                    
                    with st.spinner("🤖 Agent is analyzing documentation and generating test cases..."):
                        result = agent.generate_test_cases(user_query, n_context_chunks=n_chunks)
                    
                    if result['success']:
                        st.session_state.test_cases = result['test_cases']
                        
                        st.success(f"✅ Generated {len(result['test_cases'])} test cases!")
                        
                        st.info(f"📚 Sources used: {', '.join(result['sources_used'])}")
                        
                        st.markdown("---")
                        
                        for i, tc in enumerate(result['test_cases']):
                            with st.expander(f"**{tc.get('test_id', f'TC-{i+1}')}**: {tc.get('test_scenario', 'Test Case')}", expanded=(i < 3)):
                                col1, col2 = st.columns([2, 1])
                                
                                with col1:
                                    st.markdown(f"**Feature:** {tc.get('feature', 'N/A')}")
                                    st.markdown(f"**Type:** {tc.get('test_type', 'N/A').capitalize()}")
                                    st.markdown(f"**Scenario:** {tc.get('test_scenario', 'N/A')}")
                                
                                with col2:
                                    st.markdown(f"**Grounded In:**")
                                    st.code(tc.get('grounded_in', 'N/A'), language=None)
                                
                                if tc.get('preconditions'):
                                    st.markdown(f"**Preconditions:** {tc.get('preconditions')}")
                                
                                if tc.get('test_steps'):
                                    st.markdown("**Test Steps:**")
                                    for step in tc.get('test_steps', []):
                                        st.markdown(f"- {step}")
                                
                                if tc.get('test_data'):
                                    st.markdown("**Test Data:**")
                                    st.json(tc.get('test_data'))
                                
                                st.markdown(f"**Expected Result:** {tc.get('expected_result', 'N/A')}")
                        
                        st.success("💡 Proceed to Phase 3 to generate Selenium scripts for these test cases!")
                        
                    else:
                        st.error(f"❌ {result.get('error', 'Unknown error occurred')}")
                        
                except Exception as e:
                    st.error(f"❌ Error generating test cases: {str(e)}")
        
        if st.session_state.test_cases:
            st.markdown("---")
            st.subheader("📊 Previously Generated Test Cases")
            st.info(f"You have {len(st.session_state.test_cases)} test cases available for script generation.")


elif phase == "Phase 3: Selenium Script Generation":
    st.header("⚙️ Phase 3: Selenium Script Generation")
    
    if st.session_state.kb is None:
        st.warning("⚠️ Please build the knowledge base first in Phase 1.")
    elif not st.session_state.test_cases:
        st.warning("⚠️ Please generate test cases first in Phase 2.")
    else:
        st.markdown("""
        Select a test case and generate an executable Selenium Python script.
        The script will use actual element selectors from your HTML file.
        """)
        
        test_case_options = [
            f"{tc.get('test_id', f'TC-{i+1}')}: {tc.get('test_scenario', 'Test Case')}"
            for i, tc in enumerate(st.session_state.test_cases)
        ]
        
        selected_index = st.selectbox(
            "Select a test case:",
            range(len(test_case_options)),
            format_func=lambda i: test_case_options[i]
        )
        
        selected_test_case = st.session_state.test_cases[selected_index]
        
        with st.expander("📋 View Selected Test Case Details", expanded=True):
            col1, col2 = st.columns([2, 1])
            
            with col1:
                st.markdown(f"**Test ID:** {selected_test_case.get('test_id', 'N/A')}")
                st.markdown(f"**Feature:** {selected_test_case.get('feature', 'N/A')}")
                st.markdown(f"**Scenario:** {selected_test_case.get('test_scenario', 'N/A')}")
            
            with col2:
                st.markdown(f"**Type:** {selected_test_case.get('test_type', 'N/A')}")
                st.markdown(f"**Source:** {selected_test_case.get('grounded_in', 'N/A')}")
            
            if selected_test_case.get('test_steps'):
                st.markdown("**Test Steps:**")
                for step in selected_test_case.get('test_steps', []):
                    st.markdown(f"- {step}")
        
        st.markdown("---")
        
        if st.button("🔧 Generate Selenium Script", type="primary", use_container_width=True):
            try:
                agent = SeleniumScriptAgent(st.session_state.kb)
                
                with st.spinner("🤖 Generating Selenium script with actual HTML selectors..."):
                    result = agent.generate_selenium_script(selected_test_case)
                
                if result['success']:
                    st.session_state.generated_script = result['script']
                    
                    st.success(f"✅ Selenium script generated for {result['test_case_id']}!")
                    
                    st.subheader("📝 Generated Selenium Script")
                    
                    st.code(result['script'], language='python', line_numbers=True)
                    
                    st.download_button(
                        label="💾 Download Script",
                        data=result['script'],
                        file_name=f"{result['test_case_id']}_selenium_script.py",
                        mime="text/x-python",
                        use_container_width=True
                    )
                    
                    st.info(
                        "💡 **How to run this script:**\n"
                        "1. Install Selenium: `pip install selenium`\n"
                        "2. Download ChromeDriver matching your Chrome version\n"
                        "3. Save the script as a .py file\n"
                        "4. Run: `python script_name.py`"
                    )
                    
                else:
                    st.error(f"❌ {result.get('error', 'Unknown error occurred')}")
                    
            except Exception as e:
                st.error(f"❌ Error generating Selenium script: {str(e)}")
        
        if st.session_state.generated_script:
            st.markdown("---")
            st.subheader("📄 Previously Generated Script")
            with st.expander("View Script", expanded=False):
                st.code(st.session_state.generated_script, language='python')


st.markdown("---")
st.markdown(
    "<div style='text-align: center; color: gray;'>"
    "Autonomous QA Agent | Powered by OpenAI GPT-5 & LangChain | "
    "Built with Streamlit"
    "</div>",
    unsafe_allow_html=True
)
